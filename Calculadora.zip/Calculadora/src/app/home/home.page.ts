import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  public num1: number = 0;
  public num2: number = 0;
  public operadorSelecionado: string = '+';
  public mensagemErro: string = '';

  constructor(private alertController: AlertController) {}

  async calcular() {
    this.mensagemErro = '';
  
    if (this.num2 === 0 && this.operadorSelecionado === '/') {
      this.mensagemErro = "Não é possível dividir por zero";
  
      const alertaErro = await this.alertController.create({
        header: 'Erro',
        message: this.mensagemErro,
        buttons: ['OK'],
      });
  
      await alertaErro.present();
      return;
    }
  
    let resultado: number = 0;
  
    switch (this.operadorSelecionado) {
      case '+':
        resultado = this.num1 + this.num2;
        break;
      case '-':
        resultado = this.num1 - this.num2;
        break;
      case '*':
        resultado = this.num1 * this.num2;
        break;
      case '/':
        resultado = this.num1 / this.num2;
        break;
    }
  
    const alerta = await this.alertController.create({
      header: 'Resultado',
      message: `O resultado é: ${resultado}`,
      buttons: ['OK'],
    });
  
    await alerta.present();
  }
}